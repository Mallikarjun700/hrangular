export const environment = {
  production: true,
  apiUrl: 'http://bv-b25.yuvanetworks.in/hrlaravel/public/api/'
};
