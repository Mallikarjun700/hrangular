import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-layout',
  templateUrl: './state-layout.component.html',
  styleUrls: ['./state-layout.component.scss']
})
export class StateLayoutComponent {

  constructor() { }


}
