import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roles-layout',
  templateUrl: './roles-layout.component.html',
  styleUrls: ['./roles-layout.component.scss']
})
export class RolesLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
