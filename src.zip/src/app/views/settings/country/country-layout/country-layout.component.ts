import { Component} from '@angular/core';

@Component({
  selector: 'app-country-layout',
  templateUrl: './country-layout.component.html',
  styleUrls: ['./country-layout.component.scss']
})
export class CountryLayoutComponent {

  constructor() { }


}
