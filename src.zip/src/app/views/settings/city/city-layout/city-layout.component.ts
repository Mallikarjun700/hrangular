import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-city-layout',
  templateUrl: './city-layout.component.html',
  styleUrls: ['./city-layout.component.scss']
})
export class CityLayoutComponent {

  constructor() { }

}
