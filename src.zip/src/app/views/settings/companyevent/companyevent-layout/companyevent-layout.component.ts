import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-companyevent-layout',
  templateUrl: './companyevent-layout.component.html',
  styleUrls: ['./companyevent-layout.component.scss']
})
export class CompanyeventLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
