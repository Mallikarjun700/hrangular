import {Component } from '@angular/core';

@Component({
  templateUrl: './companyprofile-layout.component.html'
})
export class CompanyprofileLayoutComponent {
  
}
