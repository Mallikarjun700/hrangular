import {Component } from '@angular/core';

@Component({
  templateUrl: './personalinfo-layout.component.html'
})
export class PersonalinfoLayoutComponent {
  
}
